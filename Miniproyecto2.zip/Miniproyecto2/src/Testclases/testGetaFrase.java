package Testclases;

import myProject.Diccionario;

import java.util.ArrayList;
import java.util.Random;

public class testGetaFrase {


}
